import { Entity } from "../models/Entity";
import { Model, connect} from 'mongoose';
import 'reflect-metadata';

console.log(__dirname);

class Repository<T extends Entity> {
    private isConnected : boolean;

    protected entityModel: Model<T> 

    public constructor(entityModel : Model<T>)
    {
        this.isConnected = false;
        this.entityModel = entityModel;
    }

    public async save(t: T): Promise<T>
    {
        try {
            this.isConnected = await this.connect(); // connect to db
            const modelT = new this.entityModel(t);
            const isSaved = await modelT.save();
            if (isSaved)
            {
                t = modelT;
            }
            
        } catch (error) {
            console.error('Error connecting to MongoDB:', error);
        }
        // use, we simply need to add it to the collection (or update if it's already there) using mongoose


        // check out what the inserted at, created at, (and _id are if it's an insert) or (only the first two if update)
        console.log(`Saved ${JSON.stringify(t)} to collection`);

        return t;
    }

    async get(filters?: Map<string, string>): Promise<T[] | null>
    {
        await this.connect(); // connect to db
        console.log('Successfully connected to MongoDB in save!');

        let results : T[] | null = null;
        const query = this.entityModel.find<T>(); // default return everything

        // use filters else return all
        if (filters && filters.size === 0) {
            // if filters then add them to the query
            // Filter results based on any provided filters
            for (const [key, value] of filters.entries()) {
                query.where(key).equals(value);
            }
        }

        results = await query.exec();


        return results;
    }

    protected async connect() : Promise<boolean>
    {
        if (this.isConnected == false)
        {
            if (this.isConnected == false)
            {
                try {
                    await connect(process.env.MONGO_DB_URI as string);
                    this.isConnected = true;
                } catch (error) {
                    console.error("Error loading data:", error);
                    throw error; // Re-throw to let caller handle
                }
            }
        }

        return this.isConnected;
    }
}

export { Repository };